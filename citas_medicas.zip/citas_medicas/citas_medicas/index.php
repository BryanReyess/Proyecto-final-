<?php 
//redireccionar a la vista de login

header('location:login.php');
 ?>